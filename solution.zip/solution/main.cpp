#include <cmath>
#include <ctime>
#include <fstream>
#include <iostream>
#include <random>
#include <string>
#include <vector>

#include "homework2_skeleton.cpp"

using namespace std;

// Helper function to generate random numbers between -1 and 1
double randomDouble() {
    static random_device rd;
    static mt19937 gen(rd());
    static uniform_real_distribution<double> dis(-1.0, 1.0);
    return dis(gen);
}

// Helper function to create a random 7D vector
Vector createRandomVector(size_t size) {
    vector<double> components(size);
    for (size_t i = 0; i < size; i++) {
        components[i] = randomDouble();
    }
    return Vector(components);
}

Vector force2D(double t) {
    // An explicit constructor is defined with two arguments in Vector class
    // Therefore, Vector iwth initializer {} creates confusion (don't know why)
    return Vector(sin(2. * t), cos(2. * t));
}

Vector force3D(double t) {
    return Vector(sin(2. * t), cos(2. * t), cos(1.5 * t));
}
Vector force7D(double t) {
    return Vector({sin(2. * t), cos(2. * t), cos(1.5 * t), sin(2 + 0.3 * t * t),
                   cos(t * t + 2. * t - 2.4), sin(-0.01 * t * t * t + 4. * t - 3.)});
}

vector<Particle> trajectory_2d(double Tmax, double dt) {
    Vector pos = createRandomVector(2);
    Vector vel(vector<double>(2, 0.0));
    double mass = 1.0;
    Particle particle(mass, pos, vel);
    vector<Particle> trajectory{particle};

    int nb_steps = Tmax / dt;
    for (int i = 0; i < nb_steps; i++) {
        double t = i * dt;
        Vector force = force2D(t);
        particle.update(t, dt, force);
        trajectory.push_back(particle);
        // particle.velocity_ = particle.velocity_ + dt * force / mass;
        // particle.position_ = particle.position_ + particle.velocity_ * dt;
    }
    return trajectory;
}

vector<Particle> trajectory_3d(double Tmax, double dt) {
    Vector pos = createRandomVector(3);
    Vector vel(vector<double>(3, 0.0));
    double mass = 1.0;
    Particle particle(mass, pos, vel);
    vector<Particle> trajectory{particle};

    int nb_steps = Tmax / dt;
    for (int i = 0; i < nb_steps; i++) {
        double t = i * dt;
        Vector force = force3D(t);
        particle.update(t, dt, force);
        trajectory.push_back(particle);
        // particle.velocity_ = particle.velocity_ + dt * force / mass;
        // particle.position_ = particle.position_ + particle.velocity_ * dt;
    }
    return trajectory;
}

// ISSUE: methods for trajectory almost the same, except for the force function
// I'd like to pass the force function as an argument.
// Can use Lambda functions, or functors.
// For now, functors are easier by overloading () in a class.

vector<Particle> trajectory_7d(double Tmax, double dt) {
    Vector pos = createRandomVector(7);
    Vector vel(vector<double>(7, 0.0));
    double mass = 1.0;
    Particle particle(mass, pos, vel);  // Vector(vector<double>(4, 0.0)));
    vector<Particle> trajectory{particle};

    int nb_steps = Tmax / dt;
    for (int i = 0; i < nb_steps; i++) {
        double t = i * dt;
        Vector force = force7D(t);
        particle.update(t, dt, force);
        trajectory.push_back(particle);
        // particle.velocity_ = particle.velocity_ + dt * force / mass;
        // particle.position_ = particle.position_ + particle.velocity_ * dt;
    }
    return trajectory;
}

/**
 * Save a 2D trajectory to a file named "trajectory_2d.out"
 *
 * @param trajectory Vector of Particle objects representing the 2D trajectory
 * @param dt Time step used in the simulation
 * @return true if file was successfully written, false otherwise
 */
bool saveTrajectory2D(const vector<Particle>& trajectory, double dt) {
    ofstream file("trajectory_2d.out");
    if (!file.is_open()) {
        cerr << "Error: Could not open file trajectory_2d.out for writing" << endl;
        return false;
    }

    // Write header
    file << "# time x y" << endl;

    // Write trajectory data
    for (size_t i = 0; i < trajectory.size(); i++) {
        double t = i * dt;
        double x = trajectory[i].position_[0];
        double y = trajectory[i].position_[1];
        file << t << " " << x << " " << y << endl;
    }

    file.close();
    cout << "2D trajectory saved to trajectory_2d.out" << endl;
    return true;
}

/**
 * Save a 3D trajectory to a file named "traject_3d.txt"
 *
 * @param trajectory Vector of Particle objects representing the 3D trajectory
 * @param dt Time step used in the simulation
 * @return true if file was successfully written, false otherwise
 */
bool saveTrajectory3D(const vector<Particle>& trajectory, double dt) {
    ofstream file("trajectory_3d.out");
    if (!file.is_open()) {
        cerr << "Error: Could not open file traject_3d.txt for writing" << endl;
        return false;
    }

    // Write header
    file << "# time x y z" << endl;

    // Write trajectory data
    for (size_t i = 0; i < trajectory.size(); i++) {
        double t = i * dt;
        double x = trajectory[i].position_[0];
        double y = trajectory[i].position_[1];
        double z = trajectory[i].position_[2];
        file << t << " " << x << " " << y << " " << z << endl;
    }

    file.close();
    cout << "3D trajectory saved to traject_3d.txt" << endl;
    return true;
}

/**
 * Save a 7D trajectory to a file named "traject_7d.txt"
 *
 * @param trajectory Vector of Particle objects representing the 7D trajectory
 * @param dt Time step used in the simulation
 * @return true if file was successfully written, false otherwise
 */
bool saveTrajectory7D(const vector<Particle>& trajectory, double dt) {
    ofstream file("trajectory_7d.out");
    if (!file.is_open()) {
        cerr << "Error: Could not open file traject_7d.txt for writing" << endl;
        return false;
    }

    // Write header
    file << "# time x1 x2 x3 x4 x5 x6 x7" << endl;

    // Write trajectory data
    for (size_t i = 0; i < trajectory.size(); i++) {
        double t = i * dt;
        file << t;
        for (int j = 0; j < 7; j++) {
            file << " " << trajectory[i].position_[j];
        }
        file << endl;
    }

    file.close();
    cout << "7D trajectory saved to traject_7d.txt" << endl;
    return true;
}

int main() {
    // Add code to record the movement of 2D and 3D particles based on Euler's formula
    // (seen homework assignment pdf file)

    // Output the 2D and 3D trajectories to two files whose names are read from the command line.
    // "traject_3d.txt". Do not change the file names.
    // "traject_2d.txt" should contain three columns: time, x, y
    // "traject_3d.txt" should contain four columns: time, x, y, z
    // For 7-D vector for example, create the file "traject_7d.txt"

    double dt = 0.02;

    // return via copy: copies the entire vector of particles. But that
    vector<Particle> traj2d = trajectory_2d(4., dt);
    vector<Particle> traj3d = trajectory_3d(4., dt);
    vector<Particle> traj5d = trajectory_7d(4., dt);

    // Save 2D trajectory to file
    saveTrajectory2D(traj2d, dt);

    // Save 3D trajectory to file
    saveTrajectory3D(traj3d, dt);

    // Save 7D trajectory to file
    saveTrajectory7D(traj5d, dt);

    // Then read this file with a Python program and visualize the data. Create one plot for the 2D
    // trajectory, and another plot for the 3D trajectory. Add axis labels and title for each plot.
    // Store the plot in images/ folder.

    return 0;
}
