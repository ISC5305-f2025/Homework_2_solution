def main():
    print("Hello from solution!")


if __name__ == "__main__":
    main()
