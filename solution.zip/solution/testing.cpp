#include <cmath>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

// Not a best practice
#include "homework2_skeleton.cpp"

using namespace std;

// Leave this function unchanged, but call it from main <<<<<
void test_operators() {
    cout << "Inside test operators" << endl;

    Vector v1(1.0, 2.0);
    Vector v2(3.0, 4.0);
    cout << "v2: " << v2 << endl;
    cout << "v1: " << v1 << endl;
    cout << "3.2 * v1: " << 3.2 * v1 << endl;
    cout << "v1 * 3.2: " << v1 * 3.2 << endl;
    cout << "v1 + v2: " << v1 + v2 << endl;
    double prod;
    prod = (2. * v1 + 3. * v2) * (v1 + v2);
    cout << "( 2.*v1 + 3.*v2 ) * (v1 + v2) = " << prod << endl;
    prod = (2. * v1 + 3. * v2) * v1;
    cout << "( 2.*v1 + 3.*v2 ) * v1 = " << prod << endl;
    prod = v1 * v2;
    cout << "v1 * v2 : " << prod << endl;
    cout << "Vector addition: " << v1 << " + " << v2 << " = " << v1 + v2 << endl;
}

// ----------------------------------------------------------------------

void testAddition() {
    // Notice: the vector is 4-D
    // a({...}) is appropriate for Vector(const std::vector<double>& components_)
    // What is happening?
    // Initialize a vector using {...}
    vector<double> comp{2., 3., 6., 2., -2.};

    // The vector argument of the Vector constructor is initialized with {...}
    // It is possible to add to the Vector class so that
    // Vector a{.2, 2.3, 5.2, -2.} is valid. For that, one uses the concept
    // of initializers (not yet covered).
    Vector a({.2, 2.3, 5.2, -2.});
    Vector b({.3, 3.8, 4.2, 4.});
    Vector expected({.5, 6.1, 9.4, 2.});
    Vector c = a + b;
    assert(c[0] == .5);
    assert(c[1] == 6.1);
    assert(c[2] == 9.4);
    assert(c[3] == 2.);
    assert(c == expected);
    assert(c.size() == 4);
    cout << "==> testAddition(4D) passed" << endl;

    Vector a1({.1, .2, .1, .2, .3, .2, .1});
    Vector b1({.1, .2, .1, .2, .3, .2, .1});
    Vector c1 = a1 + b1;
    Vector expected1({.2, .4, .2, .4, .6, .4, .2});
    assert(c1 == expected1);
    cout << "==> testAddition(7D) passed" << endl;
}

// Fill in the following functions
void testSubtraction() {
    Vector a({.2, 2.3, 5.2, -2.});
    Vector b({.3, 3.8, 4.2, 4.});
    Vector expected({-.1, -1.5, 1., -6.});
    Vector c = a - b;
    for (size_t i = 0; i < c.size(); i++) {
        assert(fabs(c[i] - expected[i]) < 1e-6);
    }
    assert(c == expected);
    cout << "==> testSubtraction(4D) passed" << endl;

    Vector a1({.1, .2, .1, .2, .3, .2, .1});
    Vector b1({.1, .2, .1, .2, .3, .2, .1});
    Vector c1 = a1 - b1;
    Vector expected1({.0, .0, .0, .0, .0, .0, .0});
    assert(c1 == expected1);
    cout << "==> testSubtraction(7D) passed" << endl;
}

void testMultByDouble() {
    Vector a({.2, 2.3, 5.2, -2.});
    Vector expected({.4, 4.6, 10.4, -4.});
    Vector c = a * 2.;
    for (size_t i = 0; i < c.size(); i++) {
        assert(fabs(c[i] - expected[i]) < 1e-6);
    }
    assert(c == expected);
    cout << "==> testMultByDouble(4D) passed" << endl;

    Vector a1({.1, .2, .1, .2, .3, .2, .1});
    Vector expected1({.2, .4, .2, .4, .6, .4, .2});
    Vector c1 = a1 * 2.;
    for (size_t i = 0; i < c1.size(); i++) {
        assert(fabs(c1[i] - expected1[i]) < 1e-6);
    }
    assert(c1 == expected1);
    cout << "==> testMultByDouble(7D) passed" << endl;

    // Add tests for 2. * a1
    Vector c2 = 2. * a1;
    for (size_t i = 0; i < c2.size(); i++) {
        assert(fabs(c2[i] - expected1[i]) < 1e-6);
    }
    assert(c2 == expected1);
    cout << "==> testMultByDouble(7D) passed" << endl;
}

void testEqualityVector() {
    // test == operator for Vector
    Vector a({.2, 2.3, 5.2, -2.});
    Vector b({.2, 2.3, 5.2, -2.});
    assert(a == b);
    cout << "==> testEqualityVector(4D) passed" << endl;

    Vector a1({.1, .2, .1, .2, .3, .2, .1});
    Vector b1({.1, .2, .1, .2, .3, .2, .1});
    assert(a1 == b1);
    cout << "==> testEqualityVector(7D) passed" << endl;
}

void testInequalityVector() {
    Vector a({.2, 2.3, 5.2, -2.});
    Vector b({.2, 2.3, 5.2, -2.});
    assert(a != b);
    cout << "==> testInequalityVector(4D) passed" << endl;
}

void testEqualityParticle() {
    // test == operator for Particle
    // Create 7D vectors for position, velocity, and force
    Vector pos1({.1, .2, .3, .4, .5, .6, .7});
    Vector vel1({.2, .3, .4, .5, .6, .7, .8});
    Vector force1({.3, .4, .5, .6, .7, .8, .9});

    Vector pos2({.1, .2, .3, .4, .5, .6, .7});
    Vector vel2({.2, .3, .4, .5, .6, .7, .8});
    Vector force2({.3, .4, .5, .6, .7, .8, .9});

    Particle a(1.0, pos1, vel1, force1);
    Particle b(1.0, pos2, vel2, force2);
    assert(a == b);
    cout << "==> testEqualityParticle(7D) passed" << endl;
}

void testCoutVector() {
    Vector a({.2, 2.3, 5.2, -2.});

    // Capture the output using stringstream
    stringstream ss1;
    ss1 << a;
    string actual1 = ss1.str();
    string expected1 = "(.2, 2.3, 5.2, -2)";
    assert(actual1 == expected1);
    cout << "==> testCoutVector(4D) passed" << endl;

    Vector a1({.1, .2, .1, .2, .3, .2, .1});
    stringstream ss2;
    ss2 << a1;
    string actual2 = ss2.str();
    string expected2 = "(.1, .2, .1, .2, .3, .2, .1)";
    assert(actual2 == expected2);
    cout << "==> testCoutVector(7D) passed" << endl;
}

void testCoutParticle() {
    // Create 7D vectors for position, velocity, and force
    Vector pos({.1, .2, .3, .4, .5, .6, .7});
    Vector vel({.2, .3, .4, .5, .6, .7, .8});
    Vector force({.3, .4, .5, .6, .7, .8, .9});

    Particle p(1.5, pos, vel, force);

    // Capture the output using stringstream
    stringstream ss;
    ss << p;
    string actual = ss.str();

    // Expected output based on the Particle's operator<< implementation
    string expected =
        "Position: (.1, .2, .3, .4, .5, .6, .7)\nVelocity: (.2, .3, .4, .5, .6, .7, .8)\nmass: "
        "1.5\n";
    assert(actual == expected);
    cout << "==> testCoutParticle(7D) passed" << endl;
}

//----------------------------------------------------------------------
int main() {
    // Leave as is
    test_operators();
    testAddition();
    testSubtraction();
    testMultByDouble();
    testEqualityVector();
    testEqualityParticle();
    testCoutVector();
    testCoutParticle();
}
