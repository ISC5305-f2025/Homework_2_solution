#include <cmath>
#include <iostream>
#include <string>
#include <vector>
using namespace std;

// Learn about any concept you don't know or understand with AI.
// Use the `auto` keyword a much as you can.
// Use range-based loops as much as you can.
// Everything is declared public, for simplicity

// Vector class to represent both 2D and 3D vectors
class Vector {
public:
    vector<double> components_;
    double tolerance;

public:
    Vector(vector<double> components) : components_(components), tolerance(1.e-6) {
        cout << "Vector created with components of size: " << components_.size() << endl;
    }

    // Fill and document this function <<<<<
    Vector(double x, double y) : components_{x, y}, tolerance(1.e-6) {};

    // Fill and document this function <<<<<<
    Vector(double x, double y, double z) : components_{x, y, z} {}

    // Fill and document this destructor  <<<<<
    ~Vector() {
        cout << "Vector destroyed with components of size: " << components_.size() << endl;
    };

    // Fill and document this function which returns the number of
    // components of the `Vector`   <<<<
    size_t size() const {
        return components_.size();
    }

    // Fill and document this function, which should work for any size vector  <<<<
    Vector operator+(const Vector& other) const {
        vector<double> result(components_.size());
        for (size_t i = 0; i < components_.size(); i++) {
            result[i] = components_[i] + other.components_[i];
        }
        return Vector(result);
    }

    Vector operator-(const Vector& other) const {
        vector<double> result(components_.size());
        for (size_t i = 0; i < components_.size(); i++) {
            result[i] = components_[i] - other.components_[i];
        }
        return Vector(result);
    }

    // I overloaded the [] operator
    // Add an error check in case 'i' goes out of bounds <<<<
    double operator[](const int i) const {
        return components_[i];
    }

    // Fill and document this function <<<<<
    // Product with a scalar  (vector * scalar)
    // scalar * vector won't work
    Vector operator*(const double& other) const {
        vector<double> result(components_.size());
        for (int i = 0; i < components_.size(); i++) {
            result[i] = components_[i] * other;
        }
        return Vector(result);
    }

    // Fill and document this function which should work for any size vector <<<<<
    // scalar * vector
    friend Vector operator*(const double scalar, const Vector& other) {
        return other * scalar;
    }

    // Fill and document this function <<<<<
    // Dot product: Vector * Vector
    double operator*(const Vector& other) const {
        double result = 0.;
        for (size_t i = 0; i < components_.size(); i++) {
            result += components_[i] * other.components_[i];
        }
        return result;
    }

    Vector operator/(double divisor) const {
        vector<double> result(components_.size());
        for (size_t i = 0; i < components_.size(); i++) {
            result[i] = components_[i] / divisor;
        }
        return Vector(result);
    }

    void setTolerance(double tol) {
        this->tolerance = tol;
    }

    bool operator==(const Vector& other) const {
        // Returns true if the two vectors are equal:
        // Equality: `other[i] == (*this)[i]` for all `i`
        for (size_t i = 0; i < components_.size(); i++) {
            if (abs(other[i] - (*this)[i]) > tolerance) {
                return false;
            }
        }
        return true;
    }

    bool operator!=(const Vector& other) const {
        // Returns true if the two vectors are unequal
        return !(*this == other);
    }

    friend ostream& operator<<(ostream& os, const Vector& v) {
        // Return: (v[0], v[1], ..., v[n-1])  where n is the number
        // of components
        os << "(";
        for (int i = 0; i < v.components_.size(); i++) {
            os << v.components_[i];
            if (i < v.components_.size() - 1) {
                os << ", ";
            }
        }
        os << ")";
        return os;
    }
    double norm(const Vector& v, const string type) {
        // Fill and document this function. Type is "L1", "L2", or "Linf"
        double result = 0.;
        if (type == "L1") {
            for (size_t i = 0; i < v.size(); i++) {
                result += abs(v.components_[i]);
            }
        } else if (type == "L2") {
            for (size_t i = 0; i < v.size(); i++) {
                result += v.components_[i] * v.components_[i];
            }
            result = sqrt(result);
        } else if (type == "Linf") {
            for (size_t i = 0; i < v.size(); i++) {
                result = max(result, abs(v.components_[i]));
            }
        }
        return sqrt(result);
    }
};

// Fill and document this function. Note the pass by reference and the fact that the
// force `f` is not `const`. The reference mean that `f` points to an
// existing variable. `f` is used with a dot like a normal variable, but in
// reality is an address. Therefore, changing `f` inside the function, changes
// it in the calling function.
Vector& force(Vector& f, double t) {
    return f;
}

// Particle class to represent particles with mass, position, velocity, and force
class Particle {
public:
    double mass_;
    Vector position_;
    Vector velocity_;
    // Vector force_;

public:
    // Last twos argument are position and velocity at time zero
    // Particle(double mass, const Vector& position, const Vector& velocity, const Vector& force)
    Particle(double mass, const Vector& position, const Vector& velocity)
        : mass_(mass), position_(position), velocity_(velocity) {
        cout << "Particle created at position " << position_ << endl;
    }

    ~Particle() {
        cout << "Particle destroyed at position " << position_ << endl;
    }

    void updatePosition(double time_increment) {
        // update particle position and velocity
    }

    // Fill this function  <<<<<<
    // Update particle properties at time t, using time step dt.
    // force_: force applied to the particle
    void update(double t, double dt, Vector& force_) {
        position_ = position_ + velocity_ * dt;
        velocity_ = velocity_ + (force_ * dt) / mass_;
    }

    // Fill and document this function  (NEEDED???)
    Vector& force(Vector& f, double t) {
        return f;
    }

    bool operator==(const Particle& particle) {
        // Equality if both vector and position are equal to within tolerance
        bool pos_eq = position_ == particle.position_;
        bool vel_eq = velocity_ == particle.velocity_;
        return pos_eq && vel_eq;
    }

    bool operator!=(const Particle& particle) {
        // Inequality if both vector and position are not equal to within tolerance
        return !(*this == particle);
    }

    friend ostream& operator<<(ostream& os, const Particle& p) {
        // print out the mass, position and velocity
        os << "Position: " << p.position_ << endl;
        os << "Velocity: " << p.velocity_ << endl;
        os << "mass: " << p.mass_ << endl;
        return os;
    }
};