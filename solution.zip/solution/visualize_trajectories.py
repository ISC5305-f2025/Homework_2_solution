import matplotlib.pyplot as plt
import numpy as np


def visualize_trajectory(filename):
    with open(filename, "r") as file:
        lines = file.readlines()
        x_list = []
        y_list = []
        y = []
        for i, line in enumerate(lines):
            if line.startswith("#"):
                continue
            data = line.strip().split()
            time = float(data[0])
            x = float(data[1])
            y = float(data[2])
            x_list.append(x)
            y_list.append(y)

    plt.plot(x_list, y_list)
    plt.xlabel("X")
    plt.ylabel("Y")
    plt.title(f"Trajectory of {filename}")
    plt.grid(True)
    plt.savefig(f'images/{filename.replace(".out", ".png")}')
    plt.close()


def read_file_2d(filename):
    """Read 2D trajectory file and return velocity components and speeds"""
    with open(filename, "r") as file:
        lines = file.readlines()
        velocities = []
        speeds = []

        for line in lines:
            if line.startswith("#"):
                continue
            data = line.strip().split()
            time = float(data[0])
            x = float(data[1])
            y = float(data[2])

            # For 2D, we need to compute velocity from position differences
            # This is a simplified approach - in practice you'd want to store velocities
            velocities.append([x, y])  # Position as proxy for velocity
            speed = np.sqrt(x * x + y * y)  # Magnitude
            speeds.append(speed)

    return {"velocity": np.array(velocities), "speed": np.array(speeds)}


def read_file_3d(filename):
    """Read 3D trajectory file and return velocity components and speeds"""
    with open(filename, "r") as file:
        lines = file.readlines()
        velocities = []
        speeds = []

        for line in lines:
            if line.startswith("#"):
                continue
            data = line.strip().split()
            time = float(data[0])
            x = float(data[1])
            y = float(data[2])
            z = float(data[3])

            velocities.append([x, y, z])
            speed = np.sqrt(x * x + y * y + z * z)
            speeds.append(speed)

    return {"velocity": np.array(velocities), "speed": np.array(speeds)}


def read_file_7d(filename):
    """Read 7D trajectory file and return velocity components and speeds"""
    with open(filename, "r") as file:
        lines = file.readlines()
        velocities = []
        speeds = []

        for line in lines:
            if line.startswith("#"):
                continue
            data = line.strip().split()
            time = float(data[0])
            coords = [float(data[i]) for i in range(1, 8)]  # x1 to x7

            velocities.append(coords)
            speed = np.sqrt(sum(coord * coord for coord in coords))
            speeds.append(speed)

    return {"velocity": np.array(velocities), "speed": np.array(speeds)}


def visualize_speed():
    """Visualize speed over time for 2D, 3D, and 7D trajectories"""
    plt.figure(figsize=(12, 8))

    # Load 2D data
    data_2d = read_file_2d("trajectory_2d.out")
    time_2d = np.linspace(0, 4, len(data_2d["speed"]))  # Assuming 4 second simulation

    plt.subplot(2, 2, 1)
    plt.plot(time_2d, data_2d["speed"], "b-", linewidth=2, label="2D Speed")
    plt.xlabel("Time")
    plt.ylabel("Speed")
    plt.title("2D Trajectory Speed")
    plt.grid(True)
    plt.legend()

    # Load 3D data
    data_3d = read_file_3d("trajectory_3d.out")
    time_3d = np.linspace(0, 4, len(data_3d["speed"]))

    plt.subplot(2, 2, 2)
    plt.plot(time_3d, data_3d["speed"], "r-", linewidth=2, label="3D Speed")
    plt.xlabel("Time")
    plt.ylabel("Speed")
    plt.title("3D Trajectory Speed")
    plt.grid(True)
    plt.legend()

    # Load 7D data
    data_7d = read_file_7d("trajectory_7d.out")
    time_7d = np.linspace(0, 4, len(data_7d["speed"]))

    plt.subplot(2, 2, 3)
    plt.plot(time_7d, data_7d["speed"], "g-", linewidth=2, label="7D Speed")
    plt.xlabel("Time")
    plt.ylabel("Speed")
    plt.title("7D Trajectory Speed")
    plt.grid(True)
    plt.legend()

    plt.tight_layout()
    plt.savefig("images/speed_over_time.png")
    plt.close()
    print("Speed visualization saved to speed_over_time.png")


visualize_trajectory("trajectory_2d.out")
visualize_trajectory("trajectory_3d.out")
visualize_trajectory("trajectory_7d.out")
visualize_speed()
